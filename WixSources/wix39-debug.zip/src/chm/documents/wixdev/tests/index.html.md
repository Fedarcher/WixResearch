---
title: Testing WiX
layout: documentation
after: ../extensions/
---

# Testing WiX

This section contains documents on how to create and execute tests for the Windows Installer XML Toolset.

* [Running Tests](tests_runningtests.html)
* [Writing Tests](tests_writingtests.html)
