---
title: WiX MSBuild Task Reference
layout: documentation
---
# WiX MSBuild Task Reference

This section explains MSBuild tasks that are included with the WiX toolset.

* [Candle Task](candle.html)
* [HeatDirectory Task](heatdirectory.html)
* [HeatFile Task](heatfile.html)
* [HeatProject Task](heatproject.html)
* [Light Task](light.html)
* [Lit Task](lit.html)
