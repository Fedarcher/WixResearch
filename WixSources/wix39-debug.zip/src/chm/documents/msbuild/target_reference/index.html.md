---
title: WiX MSBuild Target Reference
layout: documentation
---
# WiX MSBuild Target Reference

This section explains MSBuild targets that are included with the WiX toolset.

* [HarvestDirectory Target](harvestdirectory.html)
* [HarvestFile Target](harvestfile.html)
* [HarvestProjects Target](harvestprojects.html)
