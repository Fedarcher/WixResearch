---
title: Tools and Concepts
layout: documentation
after: alltools
---
# WiX Toolset Diagram

Below is a diagram showing the relationship of all of the WiX tools and the output that they generate.

&nbsp;

![WiX Toolset Diagram](~/content/WiX_Toolset_Diagram.png)
