﻿using System.Reflection;

[assembly: AssemblyDescription("Sample managed custom actions")]
